import HookExcelReader from './Helpers/HookExcelReader';
const Excel = () => {
    
    return (
        <div>            
            <HookExcelReader />
        </div>
    )
}

export default Excel
