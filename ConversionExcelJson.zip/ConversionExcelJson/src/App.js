import Excel from './Excel/Excel';

function App() {
  return (
    <Excel />
  );
}

export default App;
