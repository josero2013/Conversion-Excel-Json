# File to  json project

Convert an upload file to Json.

## npm Packages

### xlsx ### office-ui-fabric-react

## Available extensions

"xlsx", "xlsb", "xlsm", "xls", "xml", "csv", "txt", "ods", "fods", "uos", "sylk", "dif", "dbf", "prn", "qpw", "123", "wb*", "wq*", "html", "htm"


### Considerations

If a file have 2000 rows or more, the conversation can take a few seconds